'use client';

import { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend, RadarChart, PolarGrid, PolarAngleAxis, Radar } from 'recharts';

export default function HomePage() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [spotifyData, setSpotifyData] = useState(null);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [onboardingStep, setOnboardingStep] = useState(0);

  useEffect(() => {
    fetchSpotifyData();
  }, []);

  async function fetchSpotifyData() {
    try {
      setLoading(true);
      setError(null);

      const response = await fetch('/api/spotify/data');
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to fetch data');
      }

      if (!data.topTracks) {
        setSpotifyData(null);
      } else {
        setSpotifyData(data);
        setShowOnboarding(false);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  function handleLogout() {
    document.cookie = 'spotify_token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
    window.location.reload();
  }

  function startOnboarding() {
    setShowOnboarding(true);
    setOnboardingStep(0);
  }

  function nextOnboardingStep() {
    if (onboardingStep < 2) {
      setOnboardingStep(onboardingStep + 1);
    } else {
      // Go directly to login
      window.location.href = '/api/auth/login';
    }
  }

  function skipOnboarding() {
    setShowOnboarding(false);
  }

  // Loading state
  if (loading) {
    return (
      <div className="container">
        <div className="header">
          <h1>WrappedOnDemand</h1>
          <div className="loading-spinner"></div>
          <p>Loading your stats...</p>
        </div>
      </div>
    );
  }

  // Onboarding flow
  if (showOnboarding) {
    const onboardingSteps = [
      {
        title: "Welcome to WrappedOnDemand",
        description: "Get your Spotify Wrapped stats anytime you want—no waiting for December!",
        icon: "🎵"
      },
      {
        title: "Discover Your Music Personality",
        description: "See your top tracks, favorite artists, listening patterns, and music mood analysis.",
        icon: "📊"
      },
      {
        title: "Your Data, Your Privacy",
        description: "We only read your listening stats. No posting, no sharing, no storing your data.",
        icon: "🔒"
      }
    ];

    const currentStep = onboardingSteps[onboardingStep];

    return (
      <div className="container">
        <div className="onboarding-screen">
          <button onClick={skipOnboarding} className="skip-button">Skip</button>
          
          <div className="onboarding-content">
            <div className="onboarding-icon">{currentStep.icon}</div>
            <h1>{currentStep.title}</h1>
            <p>{currentStep.description}</p>
            
            <div className="onboarding-dots">
              {onboardingSteps.map((_, index) => (
                <span 
                  key={index} 
                  className={`dot ${index === onboardingStep ? 'active' : ''}`}
                />
              ))}
            </div>
            
            <button onClick={nextOnboardingStep} className="onboarding-button">
              {onboardingStep === 2 ? 'Get Started' : 'Next'}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Login screen (not logged in)
  if (!spotifyData) {
    return (
      <div className="container">
        <div className="hero-section">
          <div className="hero-content">
            <h1 className="hero-title">
              Your Spotify Wrapped,<br />
              <span className="gradient-text">On Demand</span>
            </h1>
            <p className="hero-subtitle">
              Don't wait until December. See your listening stats right now.
            </p>
            
            <div className="feature-cards">
              <div className="feature-card">
                <div className="feature-icon">🎧</div>
                <h3>Top Tracks</h3>
                <p>Your most played songs</p>
              </div>
              <div className="feature-card">
                <div className="feature-icon">⭐</div>
                <h3>Top Artists</h3>
                <p>Who you can't stop listening to</p>
              </div>
              <div className="feature-card">
                <div className="feature-icon">🎨</div>
                <h3>Genre Analysis</h3>
                <p>Your musical taste profile</p>
              </div>
              <div className="feature-card">
                <div className="feature-icon">💫</div>
                <h3>Music Personality</h3>
                <p>Energy, mood, and vibes</p>
              </div>
            </div>

            <div className="cta-section">
              <a href="/api/auth/login" className="login-button-large">
                <span className="spotify-icon">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z"/>
                  </svg>
                </span>
                Log in with Spotify
              </a>
              <p className="privacy-note">
                Safe and secure • We only read your stats • No posting or sharing
              </p>
              <button onClick={startOnboarding} className="learn-more-button">
                Learn more about how it works
              </button>
            </div>
          </div>

          {error && (
            <div className="error" style={{ marginTop: '20px' }}>
              Error: {error}
            </div>
          )}
        </div>
      </div>
    );
  }

  // Stats dashboard (logged in)
  const COLORS = ['#1DB954', '#1ed760', '#169c46', '#0d7a38', '#085c2a'];

  // Prepare radar chart data for music personality
  const personalityData = [
    { trait: 'Energy', value: Math.round(spotifyData.audioFeatures.energy * 100) },
    { trait: 'Dance', value: Math.round(spotifyData.audioFeatures.danceability * 100) },
    { trait: 'Positivity', value: Math.round(spotifyData.audioFeatures.valence * 100) },
  ];

  return (
    <div className="container">
      <div className="dashboard-header">
        <div>
          <h1>Your Music Stats</h1>
          <p className="subtitle">Based on your last 6 months of listening</p>
        </div>
        <button onClick={handleLogout} className="logout-button">
          Log out
        </button>
      </div>

      {error && <div className="error">{error}</div>}

      <div className="stats-grid">
        {/* Top Tracks */}
        <div className="stat-card large-card">
          <div className="card-header">
            <h2>🎧 Your Top Tracks</h2>
            <span className="count-badge">{spotifyData.topTracks.length} tracks</span>
          </div>
          <ul className="item-list">
            {spotifyData.topTracks.slice(0, 10).map((track, index) => (
              <li key={track.id} className="track-item">
                <span className="item-rank">#{index + 1}</span>
                {track.album?.images?.[2]?.url && (
                  <img 
                    src={track.album.images[2].url} 
                    alt={track.name}
                    className="track-image"
                  />
                )}
                <div className="track-info">
                  <div className="item-name">{track.name}</div>
                  <div className="item-artist">{track.artists[0].name}</div>
                </div>
              </li>
            ))}
          </ul>
        </div>

        {/* Top Artists */}
        <div className="stat-card large-card">
          <div className="card-header">
            <h2>⭐ Your Top Artists</h2>
            <span className="count-badge">{spotifyData.topArtists.length} artists</span>
          </div>
          <ul className="item-list">
            {spotifyData.topArtists.slice(0, 10).map((artist, index) => (
              <li key={artist.id} className="artist-item">
                <span className="item-rank">#{index + 1}</span>
                {artist.images?.[2]?.url && (
                  <img 
                    src={artist.images[2].url} 
                    alt={artist.name}
                    className="artist-image"
                  />
                )}
                <div className="artist-info">
                  <div className="item-name">{artist.name}</div>
                  <div className="item-artist">
                    {artist.genres.slice(0, 2).join(', ') || 'Various genres'}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>

        {/* Top Genres Bar Chart */}
        <div className="stat-card chart-card">
          <div className="card-header">
            <h2>🎨 Your Genre Distribution</h2>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={spotifyData.topGenres.slice(0, 8)}>
              <XAxis dataKey="genre" angle={-45} textAnchor="end" height={120} />
              <YAxis />
              <Tooltip />
              <Bar dataKey="count" fill="#1DB954" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Music Personality Radar */}
        <div className="stat-card chart-card">
          <div className="card-header">
            <h2>💫 Your Music Personality</h2>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <RadarChart data={personalityData}>
              <PolarGrid stroke="#e0e0e0" />
              <PolarAngleAxis dataKey="trait" />
              <Radar name="You" dataKey="value" stroke="#1DB954" fill="#1DB954" fillOpacity={0.6} />
              <Tooltip />
            </RadarChart>
          </ResponsiveContainer>
          <div className="personality-details">
            <div className="personality-item">
              <strong>Energy:</strong> {Math.round(spotifyData.audioFeatures.energy * 100)}%
              <span className="personality-label">
                {spotifyData.audioFeatures.energy > 0.6 ? ' High energy tracks' : ' Chill vibes'}
              </span>
            </div>
            <div className="personality-item">
              <strong>Danceability:</strong> {Math.round(spotifyData.audioFeatures.danceability * 100)}%
              <span className="personality-label">
                {spotifyData.audioFeatures.danceability > 0.6 ? ' Dance-worthy' : ' More relaxed'}
              </span>
            </div>
            <div className="personality-item">
              <strong>Positivity:</strong> {Math.round(spotifyData.audioFeatures.valence * 100)}%
              <span className="personality-label">
                {spotifyData.audioFeatures.valence > 0.6 ? ' Positive mood' : ' Reflective mood'}
              </span>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="stat-card stats-summary">
          <h2>📈 Quick Stats</h2>
          <div className="quick-stats">
            <div className="quick-stat">
              <div className="stat-value">{spotifyData.topTracks.length}</div>
              <div className="stat-label">Top Tracks Analyzed</div>
            </div>
            <div className="quick-stat">
              <div className="stat-value">{spotifyData.topArtists.length}</div>
              <div className="stat-label">Artists You Love</div>
            </div>
            <div className="quick-stat">
              <div className="stat-value">{spotifyData.topGenres.length}</div>
              <div className="stat-label">Different Genres</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}