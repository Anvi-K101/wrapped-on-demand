import cookie from 'cookie';

export default function handler(req, res) {
  // This will add a new account (same login flow but with a flag)
  const scopes = [
    'user-top-read',
    'user-read-recently-played',
  ];

  const spotifyAuthUrl = new URL('https://accounts.spotify.com/authorize');
  spotifyAuthUrl.searchParams.append('client_id', process.env.SPOTIFY_CLIENT_ID);
  spotifyAuthUrl.searchParams.append('response_type', 'code');
  spotifyAuthUrl.searchParams.append('redirect_uri', process.env.SPOTIFY_REDIRECT_URI);
  spotifyAuthUrl.searchParams.append('scope', scopes.join(' '));
  spotifyAuthUrl.searchParams.append('show_dialog', 'true'); // Force account selection

  res.redirect(spotifyAuthUrl.toString());
}