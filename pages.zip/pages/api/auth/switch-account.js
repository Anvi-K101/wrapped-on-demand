import cookie from 'cookie';

export default function handler(req, res) {
  const { accountId } = req.query;

  if (!accountId) {
    return res.status(400).json({ error: 'Account ID required' });
  }

  const cookies = cookie.parse(req.headers.cookie || '');
  let accounts = {};
  
  try {
    accounts = cookies.spotify_accounts ? JSON.parse(decodeURIComponent(cookies.spotify_accounts)) : {};
  } catch (e) {
    return res.status(400).json({ error: 'No accounts found' });
  }

  const account = accounts[accountId];
  if (!account) {
    return res.status(404).json({ error: 'Account not found' });
  }

  const cookieOptions = {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    maxAge: 3600,
    path: '/',
    sameSite: 'lax',
  };

  res.setHeader('Set-Cookie', [
    cookie.serialize('spotify_token', account.token, cookieOptions),
    cookie.serialize('current_account_id', accountId, {
      ...cookieOptions,
      httpOnly: false,
    }),
  ]);

  res.status(200).json({ success: true });
}