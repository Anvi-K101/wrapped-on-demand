import cookie from 'cookie';

export default async function handler(req, res) {
  const code = req.query.code;

  if (!code) {
    return res.redirect('/?error=no_code');
  }

  try {
    const tokenResponse = await fetch('https://accounts.spotify.com/api/token', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Basic ' + Buffer.from(
          process.env.SPOTIFY_CLIENT_ID + ':' + process.env.SPOTIFY_CLIENT_SECRET
        ).toString('base64'),
      },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        code: code,
        redirect_uri: process.env.SPOTIFY_REDIRECT_URI,
      }),
    });

    const tokenData = await tokenResponse.json();

    if (!tokenResponse.ok) {
      console.error('Spotify token error:', tokenData);
      return res.redirect('/?error=token_exchange_failed');
    }

    // Get user profile to create unique cookie
    const profileResponse = await fetch('https://api.spotify.com/v1/me', {
      headers: { Authorization: `Bearer ${tokenData.access_token}` },
    });

    const profile = await profileResponse.json();

    // Parse existing accounts
    const cookies = cookie.parse(req.headers.cookie || '');
    let accounts = {};
    try {
      accounts = cookies.spotify_accounts ? JSON.parse(decodeURIComponent(cookies.spotify_accounts)) : {};
    } catch (e) {
      accounts = {};
    }

    // Add or update this account
    accounts[profile.id] = {
      token: tokenData.access_token,
      displayName: profile.display_name,
      image: profile.images?.[0]?.url || null,
      addedAt: Date.now(),
    };

    // Set the main token cookie (for current active account)
    const cookieOptions = {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      maxAge: 3600,
      path: '/',
      sameSite: 'lax',
    };

    // Store multiple accounts and set current account
    res.setHeader('Set-Cookie', [
      cookie.serialize('spotify_token', tokenData.access_token, cookieOptions),
      cookie.serialize('spotify_accounts', encodeURIComponent(JSON.stringify(accounts)), {
        ...cookieOptions,
        httpOnly: false, // Need to read this in frontend
      }),
      cookie.serialize('current_account_id', profile.id, {
        ...cookieOptions,
        httpOnly: false,
      }),
    ]);

    res.redirect('/');
  } catch (error) {
    console.error('Auth callback error:', error);
    res.redirect('/?error=auth_failed');
  }
}