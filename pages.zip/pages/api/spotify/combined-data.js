import cookie from 'cookie';

export default async function handler(req, res) {
  const cookies = cookie.parse(req.headers.cookie || '');
  const timeRange = req.query.timeRange || 'medium_term';
  
  let accounts = {};
  try {
    accounts = cookies.spotify_accounts ? JSON.parse(decodeURIComponent(cookies.spotify_accounts)) : {};
  } catch (e) {
    return res.status(400).json({ error: 'No accounts found' });
  }

  if (Object.keys(accounts).length === 0) {
    return res.status(200).json({ topTracks: null });
  }

  try {
    // Fetch data from all accounts
    const allAccountsData = await Promise.all(
      Object.entries(accounts).map(async ([accountId, accountInfo]) => {
        try {
          const [tracksRes, artistsRes, profileRes] = await Promise.all([
            fetch(`https://api.spotify.com/v1/me/top/tracks?limit=50&time_range=${timeRange}`, {
              headers: { Authorization: `Bearer ${accountInfo.token}` },
            }),
            fetch(`https://api.spotify.com/v1/me/top/artists?limit=50&time_range=${timeRange}`, {
              headers: { Authorization: `Bearer ${accountInfo.token}` },
            }),
            fetch('https://api.spotify.com/v1/me', {
              headers: { Authorization: `Bearer ${accountInfo.token}` },
            }),
          ]);

          if (!tracksRes.ok || !artistsRes.ok || !profileRes.ok) {
            return null;
          }

          const [tracks, artists, profile] = await Promise.all([
            tracksRes.json(),
            artistsRes.json(),
            profileRes.json(),
          ]);

          return { accountId, profile, tracks: tracks.items, artists: artists.items };
        } catch (err) {
          console.error(`Error fetching data for account ${accountId}:`, err);
          return null;
        }
      })
    );

    // Filter out failed requests
    const validData = allAccountsData.filter(d => d !== null);

    if (validData.length === 0) {
      return res.status(401).json({ error: 'All accounts have expired tokens' });
    }

    // Combine tracks from all accounts
    const trackMap = new Map();
    const artistMap = new Map();
    const genreCounts = {};

    validData.forEach(accountData => {
      // Combine tracks (deduplicate by track ID, sum play counts by occurrence)
      accountData.tracks.forEach(track => {
        if (trackMap.has(track.id)) {
          trackMap.get(track.id).count += 1;
        } else {
          trackMap.set(track.id, { ...track, count: 1 });
        }
      });

      // Combine artists
      accountData.artists.forEach(artist => {
        if (artistMap.has(artist.id)) {
          artistMap.get(artist.id).count += 1;
        } else {
          artistMap.set(artist.id, { ...artist, count: 1 });
        }

        // Count genres
        artist.genres.forEach(genre => {
          genreCounts[genre] = (genreCounts[genre] || 0) + 1;
        });
      });
    });

    // Sort by count (frequency across accounts)
    const combinedTracks = Array.from(trackMap.values())
      .sort((a, b) => b.count - a.count)
      .slice(0, 50);

    const combinedArtists = Array.from(artistMap.values())
      .sort((a, b) => b.count - a.count)
      .slice(0, 50);

    const topGenres = Object.entries(genreCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([genre, count]) => ({ genre, count }));

    // Get audio features for top combined tracks
    const trackIds = combinedTracks.slice(0, 20).map(t => t.id).join(',');
    const firstValidToken = validData[0].tracks.length > 0 ? accounts[validData[0].accountId].token : null;

    let avgFeatures = { energy: 0, danceability: 0, valence: 0 };

    if (firstValidToken && trackIds) {
      const featuresRes = await fetch(
        `https://api.spotify.com/v1/audio-features?ids=${trackIds}`,
        { headers: { Authorization: `Bearer ${firstValidToken}` } }
      );

      if (featuresRes.ok) {
        const featuresData = await featuresRes.json();
        const validFeatures = featuresData.audio_features.filter(f => f !== null);
        
        if (validFeatures.length > 0) {
          validFeatures.forEach(feature => {
            avgFeatures.energy += feature.energy;
            avgFeatures.danceability += feature.danceability;
            avgFeatures.valence += feature.valence;
          });

          avgFeatures.energy /= validFeatures.length;
          avgFeatures.danceability /= validFeatures.length;
          avgFeatures.valence /= validFeatures.length;
        }
      }
    }

    res.status(200).json({
      combined: true,
      accountCount: validData.length,
      accounts: validData.map(d => ({
        id: d.profile.id,
        displayName: d.profile.display_name,
        image: d.profile.images?.[0]?.url,
      })),
      topTracks: combinedTracks,
      topArtists: combinedArtists,
      topGenres: topGenres,
      audioFeatures: avgFeatures,
      timeRange: timeRange,
    });
  } catch (error) {
    console.error('Combined data fetch error:', error);
    res.status(500).json({ error: 'Failed to fetch combined data' });
  }
}